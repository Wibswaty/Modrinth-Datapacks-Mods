# Runs every tick: handle every tracked jukebox (one marker entity each)
execute as @e[type=minecraft:marker,tag=jbp] at @s run function jbp:marker
