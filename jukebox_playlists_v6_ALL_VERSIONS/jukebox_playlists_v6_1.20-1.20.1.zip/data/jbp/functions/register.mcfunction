execute if score #debug jbp_tmp matches 1 run tellraw @a "[JBP] jukebox found, tracking it"
# Put one marker in the middle of this jukebox (unless it already has one)
execute align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @e[type=minecraft:marker,tag=jbp,distance=..0.5] run summon minecraft:marker ~ ~ ~ {Tags:["jbp"]}
