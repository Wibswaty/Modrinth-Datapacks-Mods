# Look through the 27 chest slots: #first = leftmost disc slot, #last = rightmost (-1 = none)
# Before 1.20.5 there is no component item test, so every slot is copied onto a
# temporary armor stand and checked with the jbp:is_disc predicate (#minecraft:music_discs).
summon minecraft:armor_stand ~ ~ ~ {Tags:["jbp_tmp"],Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b}
scoreboard players set #first jbp_tmp -1
scoreboard players set #last jbp_tmp -1
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.0
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 0
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 0
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.1
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 1
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 1
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.2
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 2
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 2
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.3
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 3
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 3
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.4
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 4
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 4
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.5
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 5
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 5
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.6
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 6
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 6
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.7
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 7
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 7
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.8
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 8
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 8
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.9
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 9
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 9
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.10
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 10
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 10
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.11
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 11
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 11
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.12
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 12
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 12
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.13
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 13
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 13
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.14
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 14
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 14
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.15
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 15
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 15
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.16
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 16
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 16
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.17
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 17
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 17
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.18
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 18
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 18
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.19
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 19
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 19
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.20
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 20
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 20
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.21
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 21
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 21
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.22
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 22
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 22
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.23
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 23
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 23
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.24
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 24
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 24
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.25
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 25
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 25
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~1 ~ container.26
execute if score #first jbp_tmp matches -1 if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #first jbp_tmp 26
execute if entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1,predicate=jbp:is_disc] run scoreboard players set #last jbp_tmp 26
kill @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1]
