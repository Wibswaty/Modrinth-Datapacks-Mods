# --- Simple Voice Chat Audio Player discs ---
# While a custom audio disc plays, the jukebox stores a "ChannelID" tag.
# When that tag disappears again, the audio has finished.
execute store success score #chan jbp_tmp if data block ~ ~ ~ ChannelID
scoreboard players operation #was jbp_tmp = @s jbp_cus
execute if score #chan jbp_tmp matches 1 run scoreboard players set @s jbp_cus 1
execute if score #chan jbp_tmp matches 0 if score #was jbp_tmp matches 1 run function jbp:custom_ended

# --- Normal vanilla discs ---
execute if score #chan jbp_tmp matches 0 if score #was jbp_tmp matches 0 run function jbp:vanilla_disc
