# Queue step. Needs #first / #last from jbp:scan.
# 1) the disc in the jukebox is parked on an invisible armor stand
# 2) the first disc in the chest goes into the jukebox (it starts playing)
# 3) every chest slot from #first up to #last moves one slot to the left
# 4) the parked disc goes into slot #last, i.e. the end of the queue
summon minecraft:armor_stand ~ ~ ~ {Tags:["jbp_tmp"],Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b}
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~ ~ container.0

# 2) first disc -> jukebox
execute if score #first jbp_tmp matches 0 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.0
execute if score #first jbp_tmp matches 1 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.1
execute if score #first jbp_tmp matches 2 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.2
execute if score #first jbp_tmp matches 3 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.3
execute if score #first jbp_tmp matches 4 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.4
execute if score #first jbp_tmp matches 5 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.5
execute if score #first jbp_tmp matches 6 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.6
execute if score #first jbp_tmp matches 7 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.7
execute if score #first jbp_tmp matches 8 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.8
execute if score #first jbp_tmp matches 9 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.9
execute if score #first jbp_tmp matches 10 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.10
execute if score #first jbp_tmp matches 11 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.11
execute if score #first jbp_tmp matches 12 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.12
execute if score #first jbp_tmp matches 13 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.13
execute if score #first jbp_tmp matches 14 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.14
execute if score #first jbp_tmp matches 15 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.15
execute if score #first jbp_tmp matches 16 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.16
execute if score #first jbp_tmp matches 17 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.17
execute if score #first jbp_tmp matches 18 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.18
execute if score #first jbp_tmp matches 19 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.19
execute if score #first jbp_tmp matches 20 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.20
execute if score #first jbp_tmp matches 21 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.21
execute if score #first jbp_tmp matches 22 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.22
execute if score #first jbp_tmp matches 23 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.23
execute if score #first jbp_tmp matches 24 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.24
execute if score #first jbp_tmp matches 25 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.25
execute if score #first jbp_tmp matches 26 run item replace block ~ ~ ~ container.0 from block ~ ~1 ~ container.26

# 3) shift left (ascending order matters)
execute if score #first jbp_tmp matches ..0 if score #last jbp_tmp matches 1.. run item replace block ~ ~1 ~ container.0 from block ~ ~1 ~ container.1
execute if score #first jbp_tmp matches ..1 if score #last jbp_tmp matches 2.. run item replace block ~ ~1 ~ container.1 from block ~ ~1 ~ container.2
execute if score #first jbp_tmp matches ..2 if score #last jbp_tmp matches 3.. run item replace block ~ ~1 ~ container.2 from block ~ ~1 ~ container.3
execute if score #first jbp_tmp matches ..3 if score #last jbp_tmp matches 4.. run item replace block ~ ~1 ~ container.3 from block ~ ~1 ~ container.4
execute if score #first jbp_tmp matches ..4 if score #last jbp_tmp matches 5.. run item replace block ~ ~1 ~ container.4 from block ~ ~1 ~ container.5
execute if score #first jbp_tmp matches ..5 if score #last jbp_tmp matches 6.. run item replace block ~ ~1 ~ container.5 from block ~ ~1 ~ container.6
execute if score #first jbp_tmp matches ..6 if score #last jbp_tmp matches 7.. run item replace block ~ ~1 ~ container.6 from block ~ ~1 ~ container.7
execute if score #first jbp_tmp matches ..7 if score #last jbp_tmp matches 8.. run item replace block ~ ~1 ~ container.7 from block ~ ~1 ~ container.8
execute if score #first jbp_tmp matches ..8 if score #last jbp_tmp matches 9.. run item replace block ~ ~1 ~ container.8 from block ~ ~1 ~ container.9
execute if score #first jbp_tmp matches ..9 if score #last jbp_tmp matches 10.. run item replace block ~ ~1 ~ container.9 from block ~ ~1 ~ container.10
execute if score #first jbp_tmp matches ..10 if score #last jbp_tmp matches 11.. run item replace block ~ ~1 ~ container.10 from block ~ ~1 ~ container.11
execute if score #first jbp_tmp matches ..11 if score #last jbp_tmp matches 12.. run item replace block ~ ~1 ~ container.11 from block ~ ~1 ~ container.12
execute if score #first jbp_tmp matches ..12 if score #last jbp_tmp matches 13.. run item replace block ~ ~1 ~ container.12 from block ~ ~1 ~ container.13
execute if score #first jbp_tmp matches ..13 if score #last jbp_tmp matches 14.. run item replace block ~ ~1 ~ container.13 from block ~ ~1 ~ container.14
execute if score #first jbp_tmp matches ..14 if score #last jbp_tmp matches 15.. run item replace block ~ ~1 ~ container.14 from block ~ ~1 ~ container.15
execute if score #first jbp_tmp matches ..15 if score #last jbp_tmp matches 16.. run item replace block ~ ~1 ~ container.15 from block ~ ~1 ~ container.16
execute if score #first jbp_tmp matches ..16 if score #last jbp_tmp matches 17.. run item replace block ~ ~1 ~ container.16 from block ~ ~1 ~ container.17
execute if score #first jbp_tmp matches ..17 if score #last jbp_tmp matches 18.. run item replace block ~ ~1 ~ container.17 from block ~ ~1 ~ container.18
execute if score #first jbp_tmp matches ..18 if score #last jbp_tmp matches 19.. run item replace block ~ ~1 ~ container.18 from block ~ ~1 ~ container.19
execute if score #first jbp_tmp matches ..19 if score #last jbp_tmp matches 20.. run item replace block ~ ~1 ~ container.19 from block ~ ~1 ~ container.20
execute if score #first jbp_tmp matches ..20 if score #last jbp_tmp matches 21.. run item replace block ~ ~1 ~ container.20 from block ~ ~1 ~ container.21
execute if score #first jbp_tmp matches ..21 if score #last jbp_tmp matches 22.. run item replace block ~ ~1 ~ container.21 from block ~ ~1 ~ container.22
execute if score #first jbp_tmp matches ..22 if score #last jbp_tmp matches 23.. run item replace block ~ ~1 ~ container.22 from block ~ ~1 ~ container.23
execute if score #first jbp_tmp matches ..23 if score #last jbp_tmp matches 24.. run item replace block ~ ~1 ~ container.23 from block ~ ~1 ~ container.24
execute if score #first jbp_tmp matches ..24 if score #last jbp_tmp matches 25.. run item replace block ~ ~1 ~ container.24 from block ~ ~1 ~ container.25
execute if score #first jbp_tmp matches ..25 if score #last jbp_tmp matches 26.. run item replace block ~ ~1 ~ container.25 from block ~ ~1 ~ container.26

# 4) old disc -> end of the queue
execute if score #last jbp_tmp matches 0 run item replace block ~ ~1 ~ container.0 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 1 run item replace block ~ ~1 ~ container.1 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 2 run item replace block ~ ~1 ~ container.2 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 3 run item replace block ~ ~1 ~ container.3 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 4 run item replace block ~ ~1 ~ container.4 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 5 run item replace block ~ ~1 ~ container.5 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 6 run item replace block ~ ~1 ~ container.6 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 7 run item replace block ~ ~1 ~ container.7 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 8 run item replace block ~ ~1 ~ container.8 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 9 run item replace block ~ ~1 ~ container.9 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 10 run item replace block ~ ~1 ~ container.10 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 11 run item replace block ~ ~1 ~ container.11 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 12 run item replace block ~ ~1 ~ container.12 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 13 run item replace block ~ ~1 ~ container.13 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 14 run item replace block ~ ~1 ~ container.14 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 15 run item replace block ~ ~1 ~ container.15 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 16 run item replace block ~ ~1 ~ container.16 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 17 run item replace block ~ ~1 ~ container.17 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 18 run item replace block ~ ~1 ~ container.18 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 19 run item replace block ~ ~1 ~ container.19 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 20 run item replace block ~ ~1 ~ container.20 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 21 run item replace block ~ ~1 ~ container.21 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 22 run item replace block ~ ~1 ~ container.22 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 23 run item replace block ~ ~1 ~ container.23 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 24 run item replace block ~ ~1 ~ container.24 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 25 run item replace block ~ ~1 ~ container.25 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
execute if score #last jbp_tmp matches 26 run item replace block ~ ~1 ~ container.26 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand

kill @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1]
execute if score #debug jbp_tmp matches 1 run tellraw @a ["[JBP] started disc from slot ",{"score":{"name":"#first","objective":"jbp_tmp"}},", old disc moved to slot ",{"score":{"name":"#last","objective":"jbp_tmp"}}]
