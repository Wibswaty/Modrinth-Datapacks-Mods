# Runs as + at a jukebox marker, every tick.
# This build targets versions WITHOUT /return (added in 1.20), so the early exits of
# the newer builds are split into small sub-functions instead.

# Jukebox was broken -> remove the marker
execute unless block ~ ~ ~ minecraft:jukebox run kill @s
execute if block ~ ~ ~ minecraft:jukebox run function jbp:marker_run
