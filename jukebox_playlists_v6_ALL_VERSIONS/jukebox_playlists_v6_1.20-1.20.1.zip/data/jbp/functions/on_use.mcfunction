# Runs as the player right after they put a disc into a jukebox.
# Re-arm the advancement, then ray-cast from the eyes to find the jukebox.
advancement revoke @s only jbp:use_jukebox
scoreboard players set #steps jbp_tmp 0
execute anchored eyes positioned ^ ^ ^ run function jbp:raycast
