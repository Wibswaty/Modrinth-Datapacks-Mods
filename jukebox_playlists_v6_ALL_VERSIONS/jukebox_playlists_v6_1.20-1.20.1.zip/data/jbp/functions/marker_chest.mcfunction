# Empty jukebox + chest -> start the first disc in the chest
execute store success score #has jbp_tmp if data block ~ ~ ~ RecordItem
execute if score #has jbp_tmp matches 0 run function jbp:idle
execute if score #has jbp_tmp matches 1 run function jbp:marker_disc
