# The jukebox is empty but has a chest on top: start the first disc in the chest.
scoreboard players set @s jbp_prev -1
scoreboard players set @s jbp_cus 0
function jbp:scan
execute unless score #first jbp_tmp matches -1 run function jbp:rotate
