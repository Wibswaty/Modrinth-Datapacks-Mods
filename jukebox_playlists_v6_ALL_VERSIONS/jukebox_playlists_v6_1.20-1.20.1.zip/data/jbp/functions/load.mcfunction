# Scoreboards used by the pack
scoreboard objectives add jbp_prev dummy
scoreboard objectives add jbp_cus dummy
scoreboard objectives add jbp_tmp dummy
