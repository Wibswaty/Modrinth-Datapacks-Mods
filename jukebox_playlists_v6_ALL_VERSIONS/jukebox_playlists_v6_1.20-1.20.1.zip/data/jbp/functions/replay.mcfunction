# No other disc in the chest: put the current disc back in so it plays again
execute if score #debug jbp_tmp matches 1 run tellraw @a "[JBP] no disc found in chest, replaying current disc"
summon minecraft:armor_stand ~ ~ ~ {Tags:["jbp_tmp"],Marker:1b,Invisible:1b,NoGravity:1b,Silent:1b}
item replace entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand from block ~ ~ ~ container.0
item replace block ~ ~ ~ container.0 from entity @e[type=minecraft:armor_stand,tag=jbp_tmp,limit=1,distance=..1] weapon.mainhand
kill @e[type=minecraft:armor_stand,tag=jbp_tmp,distance=..1]
