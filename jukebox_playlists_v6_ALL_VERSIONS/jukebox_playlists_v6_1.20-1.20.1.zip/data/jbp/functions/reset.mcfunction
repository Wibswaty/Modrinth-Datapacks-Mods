# No chest on top of this jukebox: never act, but keep WATCHING the song state, so a
# chest that is placed later still notices that the disc already finished (like the
# newer builds do). An empty jukebox forgets everything.
scoreboard players set @s jbp_cus 0
execute unless data block ~ ~ ~ RecordItem run scoreboard players set @s jbp_prev -1
execute store result score #now jbp_tmp run data get block ~ ~ ~ IsPlaying
execute if data block ~ ~ ~ RecordItem if score #now jbp_tmp matches 1 run scoreboard players set @s jbp_prev 1
