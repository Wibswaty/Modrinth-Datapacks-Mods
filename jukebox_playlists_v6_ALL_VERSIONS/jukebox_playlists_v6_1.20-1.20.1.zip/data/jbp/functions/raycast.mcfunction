# Step forward 0.1 blocks at a time (max 60 steps = 6 blocks) until we hit a jukebox
# (no /return before 1.20: once found, #steps is pushed past the limit to stop the recursion)
scoreboard players add #steps jbp_tmp 1
execute if block ~ ~ ~ minecraft:jukebox run function jbp:register
execute if block ~ ~ ~ minecraft:jukebox run scoreboard players set #steps jbp_tmp 999
execute unless block ~ ~ ~ minecraft:jukebox if score #steps jbp_tmp matches ..60 positioned ^ ^ ^0.1 run function jbp:raycast
