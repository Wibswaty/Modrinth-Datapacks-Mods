# First-time setup of this marker's scores
execute unless score @s jbp_prev matches -1.. run scoreboard players set @s jbp_prev -1
execute unless score @s jbp_cus matches 0.. run scoreboard players set @s jbp_cus 0

# Nothing to do without a chest above
execute store success score #chest jbp_tmp if block ~ ~1 ~ #jbp:playlist_containers
execute if score #chest jbp_tmp matches 0 run function jbp:reset
execute if score #chest jbp_tmp matches 1 run function jbp:marker_chest
