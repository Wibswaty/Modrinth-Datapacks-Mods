# A Simple Voice Chat Audio Player disc finished (its ChannelID tag disappeared).
scoreboard players set @s jbp_cus 0
execute if score #debug jbp_tmp matches 1 run tellraw @a "[JBP] custom audio disc ended"
function jbp:next
