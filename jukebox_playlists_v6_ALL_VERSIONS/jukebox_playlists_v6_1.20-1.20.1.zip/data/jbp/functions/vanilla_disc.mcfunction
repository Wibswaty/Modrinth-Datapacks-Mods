# Before 1.21 the jukebox stores an "IsPlaying" byte. It is 1 while the song runs and
# drops to 0 when the song is over (the disc itself stays inside).
# We only believe the end if we SAW it playing first (jbp_prev = 1), so a freshly
# inserted custom disc or a jukebox that is not ticking can never trigger a loop.
execute store result score #now jbp_tmp run data get block ~ ~ ~ IsPlaying
execute if score #now jbp_tmp matches 1 run scoreboard players set @s jbp_prev 1
execute if score #debug jbp_tmp matches 1 if score #now jbp_tmp matches 0 if score @s jbp_prev matches 1 run tellraw @a "[JBP] song ended (IsPlaying went to 0)"
execute if score #now jbp_tmp matches 0 if score @s jbp_prev matches 1 run function jbp:next
