# The song ended.
scoreboard players set @s jbp_prev -1
function jbp:scan
# No other disc in the chest -> play the current one again
execute if score #first jbp_tmp matches -1 run return run function jbp:replay
function jbp:rotate
