# Look through the 27 chest slots: #first = leftmost disc slot, #last = rightmost (-1 = none)
scoreboard players set #first jbp_tmp -1
scoreboard players set #last jbp_tmp -1
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.0 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 0
execute if items block ~ ~1 ~ container.0 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 0
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.1 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 1
execute if items block ~ ~1 ~ container.1 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 1
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.2 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 2
execute if items block ~ ~1 ~ container.2 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 2
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.3 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 3
execute if items block ~ ~1 ~ container.3 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 3
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.4 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 4
execute if items block ~ ~1 ~ container.4 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 4
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.5 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 5
execute if items block ~ ~1 ~ container.5 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 5
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.6 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 6
execute if items block ~ ~1 ~ container.6 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 6
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.7 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 7
execute if items block ~ ~1 ~ container.7 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 7
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.8 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 8
execute if items block ~ ~1 ~ container.8 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 8
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.9 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 9
execute if items block ~ ~1 ~ container.9 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 9
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.10 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 10
execute if items block ~ ~1 ~ container.10 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 10
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.11 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 11
execute if items block ~ ~1 ~ container.11 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 11
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.12 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 12
execute if items block ~ ~1 ~ container.12 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 12
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.13 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 13
execute if items block ~ ~1 ~ container.13 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 13
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.14 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 14
execute if items block ~ ~1 ~ container.14 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 14
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.15 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 15
execute if items block ~ ~1 ~ container.15 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 15
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.16 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 16
execute if items block ~ ~1 ~ container.16 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 16
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.17 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 17
execute if items block ~ ~1 ~ container.17 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 17
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.18 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 18
execute if items block ~ ~1 ~ container.18 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 18
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.19 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 19
execute if items block ~ ~1 ~ container.19 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 19
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.20 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 20
execute if items block ~ ~1 ~ container.20 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 20
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.21 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 21
execute if items block ~ ~1 ~ container.21 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 21
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.22 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 22
execute if items block ~ ~1 ~ container.22 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 22
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.23 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 23
execute if items block ~ ~1 ~ container.23 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 23
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.24 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 24
execute if items block ~ ~1 ~ container.24 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 24
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.25 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 25
execute if items block ~ ~1 ~ container.25 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 25
execute if score #first jbp_tmp matches -1 if items block ~ ~1 ~ container.26 *[minecraft:jukebox_playable] run scoreboard players set #first jbp_tmp 26
execute if items block ~ ~1 ~ container.26 *[minecraft:jukebox_playable] run scoreboard players set #last jbp_tmp 26
