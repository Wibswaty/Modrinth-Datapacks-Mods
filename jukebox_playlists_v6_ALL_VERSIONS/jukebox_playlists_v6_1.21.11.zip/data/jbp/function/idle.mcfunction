# The jukebox is empty but has a chest on top: start the first disc in the chest.
scoreboard players set @s jbp_prev -1
scoreboard players set @s jbp_cus 0
function jbp:scan
execute if score #first jbp_tmp matches -1 run return 0
function jbp:rotate
