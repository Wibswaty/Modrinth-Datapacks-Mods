# Step forward 0.1 blocks at a time (max 60 steps = 6 blocks) until we hit a jukebox
scoreboard players add #steps jbp_tmp 1
execute if block ~ ~ ~ minecraft:jukebox run return run function jbp:register
execute if score #steps jbp_tmp matches ..60 positioned ^ ^ ^0.1 run function jbp:raycast
