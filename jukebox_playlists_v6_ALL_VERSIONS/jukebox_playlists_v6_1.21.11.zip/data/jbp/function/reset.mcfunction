# No chest on top of this jukebox: forget all timer state.
scoreboard players set @s jbp_prev -1
scoreboard players set @s jbp_cus 0
