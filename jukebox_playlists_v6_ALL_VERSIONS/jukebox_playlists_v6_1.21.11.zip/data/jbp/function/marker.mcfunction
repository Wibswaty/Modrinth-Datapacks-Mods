# Runs as + at a jukebox marker, every tick.

# Jukebox was broken -> remove the marker
execute unless block ~ ~ ~ minecraft:jukebox run return run kill @s

# First-time setup of this marker's score
execute unless score @s jbp_prev matches -1.. run scoreboard players set @s jbp_prev -1

# Nothing to do without a chest above
execute unless block ~ ~1 ~ #jbp:playlist_containers run return run function jbp:reset

# Empty jukebox + chest -> start the first disc in the chest
execute unless data block ~ ~ ~ RecordItem run return run function jbp:idle

# --- Simple Voice Chat Audio Player discs ---
# While a custom audio disc plays, the jukebox stores a "ChannelID" tag.
# (It does NOT store ticks_since_song_started for these discs.)
# When that tag disappears again, the audio has finished.
execute if data block ~ ~ ~ ChannelID run return run scoreboard players set @s jbp_cus 1
execute if score @s jbp_cus matches 1 run return run function jbp:custom_ended

# --- Normal vanilla discs ---
# The song timer counts up while playing. If it did NOT go up, the song ended.
# We only believe that if the timer had reached 20+ ticks, so a jukebox that is
# not ticking at all (chunk too far from players) can never trigger a loop.
execute store result score #now jbp_tmp run data get block ~ ~ ~ ticks_since_song_started
scoreboard players operation #prev jbp_tmp = @s jbp_prev
scoreboard players operation @s jbp_prev = #now jbp_tmp
execute if score #debug jbp_tmp matches 1 if score #now jbp_tmp <= #prev jbp_tmp if score #prev jbp_tmp matches 20.. run tellraw @a ["[JBP] song ended. now=",{"score":{"name":"#now","objective":"jbp_tmp"}}," prev=",{"score":{"name":"#prev","objective":"jbp_tmp"}}]
execute if score #now jbp_tmp <= #prev jbp_tmp if score #prev jbp_tmp matches 20.. run function jbp:next
